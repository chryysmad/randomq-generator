#!/bin/bash
# script to build the docker image. Dynamically creates the user from `$(id -u)`
# for the user inside of the docker image. This will help guarentee files
# generated in the container will have the correct owner ship.

usage() {
    echo "Usage: $0 [-h] [-b] [-n] [-u]"
    echo " -h                               This help message"
    echo " -b                               Build the docker image, with cached layers"
    echo " -n                               Build the docker image, without cached layers"
    echo " -u                               Run docker compose up"
}

if [ "$#" -lt 1 ]; then
    usage
fi


BUILD=false
#BUILD_NO_CACHE=false
BUILD_ARGS=""
COMPOSEUP=false

while getopts "hbnu" opt; do
    case ${opt} in
        h )
            usage
            ;;
        b )
            BUILD=true
            ;;
        n )
            BUILD=true
            BUILD_ARGS="--no-cache"
            ;;
        u )
            echo "HUH"
            COMPOSEUP=true
            ;;
        * )
            usage
            ;;
    esac
done

export USER_UID=$(id -u)
# export COMPOSE_PROJECT_NAME="nuwa_onlinehtr_${USER_UID}"
# export HOSTNAME=$(hostname)

if [ "$BUILD" = true ]; then
    echo "Building docker image"
    # to build the docker image, the data volume and output volume variables need to be set as they
    # are used by the docker-compose.yml, but they do not affect the Dockerfile build. So set
    # the variables to some path that definitely exists. The variables must be properly set when
    # using docker compose up.
    if [ -n "$BUILD_ARGS" ]; then
        DATA_VOLUME=./ OUTPUT_VOLUME=./ docker compose build "$BUILD_ARGS"
    else
        DATA_VOLUME=./ OUTPUT_VOLUME=./ docker compose build
    fi
fi

if [ "$COMPOSEUP" = true ]; then
    echo "Starting docker container"
    docker compose up
fi
